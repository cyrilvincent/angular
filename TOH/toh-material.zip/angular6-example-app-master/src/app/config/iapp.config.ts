export interface IAppConfig {
  routes: any;
  endpoints: any;
  votesLimit: number;
  topHeroesLimit: number;
  snackBarDuration: number;
  repositoryURL: string;
}
